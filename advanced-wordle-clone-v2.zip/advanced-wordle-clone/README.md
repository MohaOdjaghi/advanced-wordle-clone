
# Advanced Wordle Clone

A browser-based clone of the popular game **Wordle**, built using HTML, CSS, and JavaScript.

## Features

- Fully interactive UI and responsive design
- Accepts guesses using full character set
- Implements game logic similar to the original Wordle
- Uses external APIs for word validation or suggestions (JSON-based)
- Tracks user attempts and game states
- Displays feedback (correct/wrong/misplaced letters)

## Technologies Used

- HTML5
- CSS3 (with Flexbox/Grid)
- Vanilla JavaScript (ES6+)
- RESTful APIs (JSON)

## Demo

> [Live Preview Coming Soon]

## How to Use

1. Clone the repository:
   ```bash
   git clone https://github.com/mohadesehodjaghi/advanced-wordle-clone.git
   ```

2. Open `index.html` in your browser.

## Credits

This project was built as the final project of the **Complete Intro to Web Development v3** by Brian Holt.

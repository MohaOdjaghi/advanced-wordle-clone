
const board = document.getElementById('board');
const message = document.getElementById('message');
let answer = "EXAMPLE"; // Replace with API call in real version

function submitGuess() {
    const input = document.getElementById('guessInput');
    const guess = input.value.toUpperCase();
    input.value = "";

    if (!guess || guess.length !== answer.length) {
        message.textContent = "Invalid guess.";
        return;
    }

    const row = document.createElement('div');
    for (let i = 0; i < guess.length; i++) {
        const letterBox = document.createElement('span');
        letterBox.textContent = guess[i];
        if (guess[i] === answer[i]) {
            letterBox.classList.add('correct');
        } else if (answer.includes(guess[i])) {
            letterBox.classList.add('present');
        } else {
            letterBox.classList.add('absent');
        }
        row.appendChild(letterBox);
    }
    board.appendChild(row);

    if (guess === answer) {
        message.textContent = "Congratulations! You guessed it!";
    }
}
